-- PostgreSQL: Example query
SELECT * FROM customers;
