-- PostgreSQL: Example table creation
CREATE TABLE customers (id SERIAL PRIMARY KEY, name TEXT);
