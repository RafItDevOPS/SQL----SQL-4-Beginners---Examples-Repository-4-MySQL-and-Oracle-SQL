-- SQLite: Analytical query
SELECT AVG(price) FROM products;
