-- SQLite: Insert demo data
INSERT INTO products (name, price) VALUES ('Widget', 19.99);
