-- Oracle: JOIN queries
-- INNER JOIN
SELECT customers.name, orders.total
FROM customers
JOIN orders ON customers.id = orders.customer_id;

-- LEFT JOIN
SELECT customers.name, orders.total
FROM customers
LEFT JOIN orders ON customers.id = orders.customer_id;

-- FULL OUTER JOIN
SELECT customers.name, orders.total
FROM customers
FULL OUTER JOIN orders ON customers.id = orders.customer_id;

-- Aggregation
SELECT customer_id, SUM(total) AS total_spent
FROM orders
GROUP BY customer_id;




