-- Oracle: Analytical queries
-- JOIN with filtering
SELECT c.name, o.total
FROM customers c
JOIN orders o ON c.id = o.customer_id
WHERE o.total > 50;

-- Average order value
SELECT AVG(total) AS avg_order_value FROM orders;




