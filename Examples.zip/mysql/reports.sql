-- MySQL: Reporting query
SELECT COUNT(*) FROM orders;
